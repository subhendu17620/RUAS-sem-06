/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package rmiapp_cliser;

import Interface.TestInterface;
import java.rmi.NotBoundException;
import java.rmi.RemoteException;
import java.rmi.registry.LocateRegistry;
import java.rmi.registry.Registry;
import java.util.Scanner;

/**
 *
 * @author Kishor
 */

public class Client {
    
        public static void main(String args[]) throws Exception{
            
           // Client c = new Client();
           // c.connectRemote();
            int option = 0;
            Scanner in = new Scanner(System.in);
            TestInterface t = null;
            
            try{
                Registry registry  = LocateRegistry.getRegistry("Localhost",4444);
                t = (TestInterface) registry.lookup("STUDENT");
                System.out.println("Connected to server");
                
                }
            catch (NotBoundException | RemoteException e){
                System.out.println("Exception"+e);
            } 
            
            
            System.out.println("Enter your option");
            System.out.println("1. Balance");
            System.out.println("2. Deposit Money");
            String val = in.nextLine();
            option = Integer.valueOf(val);
            
                    switch(option){
                            case 1:
                                  System.out.println("Checking balance in account");
                                  System.out.println("Balance is "+t.message());
                                break;
                                
                            case 2:
                                  System.out.println("Deposit money");
                                
                                break;
                                
                                default:
               
                                 System.out.println("Operation not supported");
                                 break;
                                
                
            }
            
            
        }

   /* private void connectRemote() throws Exception  {
        
            try{
                Registry registry  = LocateRegistry.getRegistry("Localhost",4444);
                TestInterface t = (TestInterface) registry.lookup("hi server");
                System.out.println("message is "+t.message(44, 2));
                }
            catch (NotBoundException | RemoteException e){
                System.out.println("Exception"+e);
            } 
            
    
    }*/
    
}
