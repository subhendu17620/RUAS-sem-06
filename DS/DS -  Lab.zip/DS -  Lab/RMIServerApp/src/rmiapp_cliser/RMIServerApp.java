/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package rmiapp_cliser;

import Interface.TestInterface;
import java.rmi.RemoteException;
import java.rmi.registry.LocateRegistry;
import java.rmi.registry.Registry;
import java.rmi.server.UnicastRemoteObject;



/**
 *
 * @author Kishor
 */
public class RMIServerApp extends UnicastRemoteObject implements TestInterface{

    /**
     * @param args the command line arguments
     */
  
    public static void main(String[] args) throws RemoteException{
        // TODO code application logic here
        
        try
        {
            Registry registry = LocateRegistry.createRegistry(4444);
            registry.rebind("STUDENT", new RMIServerApp());
            System.out.println("Server is ready");
            
        }
        catch(RemoteException e){
            System.out.println("Exception"+e);
        }
    }
    public RMIServerApp() throws RemoteException
    {
        super();
        
    }

    @Override
    public int message() throws Exception {
        
                
        
        return 1000;
    }


   

}
